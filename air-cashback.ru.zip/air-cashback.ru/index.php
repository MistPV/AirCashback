<?
session_start();
if ($_POST['out']=='Выход') {$_SESSION['login']=''; $_SESSION['pass1']='';}
?>
<html>
  <head>
    <title>Воздушный Кешбэк</title>
    <link rel="shortcut icon" type="image/png" href="img\favicon.png">
    <link rel="stylesheet" href="css/styles1.css">
    <meta charset="utf-8">
  </head>
  <body>
    <?php
    $host='localhost';
    $name='root';
    $pass='';
    $base='colorсlouds';

    $conn=mysqli_connect($host,$name,$pass,$base);
    ?> 
    <header>
          <div class="shapka-left">
            <a href="#afisha" class="button_header">Афиша</a>
            <a href="#profile" class="button_header">Профиль</a>
          </div>
          <img class="logotype" src="img/logo-1.png">
          <div class="shapka-right">
            <a href="#cashback" class="button_header">Кэшбэк</a>
            <a href="#reviews" class="button_header">Отзывы</a>
          </div>
    </header>
    <main>
        <h2 id="afisha" class="main-text">Афиша</h2>
        <div class="all">
          <input checked type="radio" name="respond" id="desktop">
            <article id="slider">
                <input checked type="radio" name="slider" id="switch1">
                <input type="radio" name="slider" id="switch2">
                <input type="radio" name="slider" id="switch3">
                <input type="radio" name="slider" id="switch4">
                <input type="radio" name="slider" id="switch5">
              <div id="slides">
                <div id="overflow">
                  <div class="image">
                    <article><img src="img/1.jpg"></article>
                    <article><img src="img/2.jpg"></article>
                    <article><img src="img/3.jpg"></article>
                    <article><img src="img/4.jpg"></article>
                    <article><img src="img/5.jpg"></article>
                  </div>
                </div>
              </div>
              <div id="controls">
                <label for="switch1"></label>
                <label for="switch2"></label>
                <label for="switch3"></label>
                <label for="switch4"></label>
                <label for="switch5"></label>
              </div>
              <div id="active">
                <label for="switch1"></label>
                <label for="switch2"></label>
                <label for="switch3"></label>
                <label for="switch4"></label>
                <label for="switch5"></label>
              </div>
            </article>
        </div>  
        <svg width="1830" height="50">
          <line
            x1="1820" y1="50" x2="40" y2="50"
            stroke="black" stroke-width="2"
          />
        </svg>
        <div id="profile" class="profile-main">
          <?
          if ($_SESSION['login']!='') {
          ?>
          <div class="profile-info">
              <div class="info-point">
                  <div class="points">
                    <img src="img/point.svg" height="200%">
                      <?
                      $login=$_SESSION['login'];
                      $query="SELECT * FROM `clients` WHERE `login`='$login'";
                      $result=mysqli_query($conn,$query);
                      $i=1;
                      while ($row=mysqli_fetch_array($result))
                      {
                      ?>
                    <div class="points-text">
                      <h2><? echo $row[4];?></h2>
                      </tr>  
                    </div>
                  </div>
                    <h2>Ваши баллы</h2>
                 </div>
              <td><img class="profile-ava" src="img/<? echo $row[6]; ?>" height="80%"></td>
              <form action="index.php" method="POST">
                <input class="button_exit" type="submit" name="out" value="Выход">
              </form>
              <input type="hidden" value="Вы скопировали реферальную ссылку!" id="myInput">
              <button onclick="myFunction()" class="button_referal">Поделиться<br /> ссылкой</button >
          </div>
          <?
            }
          }
          else{
          ?> 
          <h2 class="profile-text-reg">
            <a href="#modal_sign" class="button-sign_reg">Войдите</a> или 
            <a href="#modal_reg" class="button-sign_reg">Зарегистрируйте</a> свой аккаунт, <br/>чтоб видеть свою систему баллов для кэшбэка.
          </h2>
          <div id="modal_sign" class="my_modal">
            <div class="my_modal-dialog">
              <div class="my_modal-content">
                <div class="my_modal-header">
                  <p class="my_modal-title">Вход</p>
                  <a href="#" title="Закрыть модальное окно" class="close">×</a>
                </div>
                <div class="my_modal-body">
                <?
                if ($_POST['auto']=='Войти')
                {
                  $login=$_POST['login'];
                  $pass1=$_POST['pass1'];

                  $query="SELECT * FROM `clients` WHERE `login`='$login' AND `pass`='$pass1'";
                  $result=mysqli_query($conn,$query);
                  $num=mysqli_num_rows($result);
                  $row=mysqli_fetch_array($result);

                  if ($num == 1)
                  {
                    $_SESSION['login']=$login;
                    $_SESSION['pass1']=$pass1;
                  } 
                }
                else
                {
                ?>
                   <table>
                    <form action='index.php' method='post'>
                      <tr>
                       <td><label>Введите логин</label></td>
                       <td><input type='text'name='login'></td>
                      </tr>
                      <tr>
                       <td><label>Введите пароль:</label></td>
                       <td><input type='password' name ='pass1'></td>
                      </tr>
                      <tr>
                          <td><input type='submit' name='auto' value='Войти'></td>
                      </tr>    
                    </form>      
                  </table>
                <?
                }
                ?>  
                </div>    
              </div>
            </div>
          </div>
          <div id="modal_reg" class="my_modal">
            <div class="my_modal-dialog">
              <div class="my_modal-content">
                <div class="my_modal-header">
                  <p class="my_modal-title">Создание учётной записи </p>
                  <a href="#" title="Закрыть модальное окно" class="close">×</a>
                </div>
                <div class="my_modal-body">
                <?
                if ($_POST['clients']=='Создать')
                {
                  $login=$_POST['login'];
                  $mail=$_POST['mail'];
                  $number=$_POST['number'];
                  $points=$_POST['points'];
                  $pass1=$_POST['pass1'];
                  $pass2=$_POST['pass2'];
                  $img=$_POST['img'];
                 
                  $query = "INSERT INTO `clients`(`login`, `mail`, `nubmer`, `points`, `pass`, `img`) VALUES ('$login','$mail','$number','200','$pass1','$img')";
                  $result=mysqli_query($conn,$query);
                } 
                else
                {
                ?>  
                   <table>
                    <form action="index.php" method="post">
                      <tr>
                       <td><label>ф.И.О</label></td>
                       <td><input type="text" name='login'></td>
                      </tr>
                      <tr>
                       <td><label>Эл. адрес</label></td> 
                       <td><input type="text" name ='mail'></td>
                      </tr>
                      <br>
                      <tr>
                        <td><lable>Телефон</lable></td>
                        <td><input type="number" name ='number'></td>
                      </tr>
                      <tr>
                       <td><label>Пароль:</label></td>
                       <td><input type="password" name ='pass1'></td>
                      </tr>
                      <tr>
                       <td><label>Повторите пароль:</label></td>
                       <td><input type="password" name ='pass2'></td>
                      </tr>
                      <tr>
                       <td><label>Аватарка:</label></td>
                       <td><input type="file" name ='img' value='<? echo $row[6]; ?>'></td>
                      </tr>
                        <tr height="5px"></tr> 
                        <td><input type="submit" name="clients" value="Создать"></td>
                      </form>
                    </table>
                   <?
                    }
                   ?> 
                </div>    
              </div>
            </div>
          </div>
          <?
          }
          ?> 
        </div>
        <div id="cashback" class="cashback-main">
          <div class="cashback-text">
            <h2 class="main-text">Кешбэк цветные облака</h2>
              <div class="cashback-main-svg">
                <div class="csh1">
                  <img src="img/cashb-1.svg" width="130px" height="130px">
                  <p>Повышенный <br />кешбэк для <br />новых пользователей</p>
                </div>
                <div class="csh2">
                  <img src="img/cashb-2.svg" width="130px" height="130px">
                  <p>Зачисление: <br />мгновенное <br />ожидание вывода: <br />в среднем 30 дней</p>
                </div>
                <div class="csh3">
                  <img src="img/cashb-3.svg" width="130px" height="130px">
                  <p>Вывод денег: <br />от 500 рублей <br />без комиссии</p>
                </div>
            </div>
            <div class="cashback-activate">
              <img src="img/balonslogo.png" width="100%" height="80%">
              <?
              if ($_SESSION['login']!='') {
              ?>
              <a href="#" class="button_activate">Активировать</a>
              <?
              }
              else
              {
              ?>
              <div class="button_noactivate">Недоступно</div>
              <?
              }
              ?> 
            </div>
          </div>
        </div>
        <div id="reviews" class="reviews-main">
          <h2 class="main-text">Отзывы о кешбэке  
            <?
            if ($_SESSION['login']!='') {
            ?>
            <a href="#modal_reviews" class="button_reviews">Написать отзыв</a>
            <?
            }
            ?> 
          </h2>
          <?
          $query="SELECT * FROM `reviews`";
          $result=mysqli_query($conn,$query);

          while($row=mysqli_fetch_array($result))
          {
          ?>
          <div class="reviews">
            <div class="reviews-profile">
              <div class="reviews-profile-text">
                    <div class="reviews-text">
                      <h2><? echo $row[1]; ?></h2>
                      <h3><? echo $row[2]; ?></h3>
                    </div>
                  <img class="reviews-ava" src="img/ot-ava.png" height="80%">
                 </div>
            </div>
          <?
          }
          ?>
          </div>
          <div id="modal_reviews" class="my_modal">
            <div class="my_modal-dialog">
              <div class="my_modal-content">
                <div class="my_modal-header">
                  <p class="my_modal-title">Напишите отзыв</p>
                  <a href="#" title="Закрыть модальное окно" class="close">×</a>
                </div>
                <div class="my_modal-body">
                  <?
                  if ($_POST['reviews']=='Отправить')
                    {
                      $name=$_POST['name'];
                      $text=$_POST['text'];

                      $query = "INSERT INTO `reviews`(`name`,`text`) VALUES ('$name','$text')";
                        $result=mysqli_query($conn,$query);
                    }
                    else{
                  ?>
                  <table class="reviews-table">
                      <form action="#reviews" method="post">
                        <tr>
                         <td><label>Введите имя:</label></td>
                         <td><input type="text"name='name'></td>
                        </tr>
                        <tr>
                         <td><label>Введите отзыв:</label></td> 
                         <td><textarea rows="10" cols="45" name="text"></textarea></td>
                        </tr>
                        </tr>
                         <tr height="5px"></tr> 
                         <td><input type="submit" name="reviews" value="Отправить"></td>
                        </form>
                  </table>
                </div>
                <?
                }
                ?>
                </div>    
              </div>
            </div>
          </div>
        </div>
    </main>
    <footer>
      <div class="footer-main">
        <img src="img/logo-1.png" height="100%" align="left">
        <div class="footer-text">
           <p class="p1">Кешбэк-сервис "Воздушый кешбэк"</p>
            <p class="p2">pomosh@air-cashback.ru</p>
            <p>Якутск, Хангаласский райнон</p>
            <p>+7 (567) 456-29-35</p>
            <p class="p2">Пользовательское соглашение</p>
            <p class="p1">© 2022 Воздушый кешбэк. Все права защищены.</p>
        </div>
        <div class="footer-contacts">
          <a href=""><img src="img/tg.png" height="33%"></a>
          <a href=""><img src="img/wa.png" height="30%"></a>
        </div>
      </div>
    </footer>
  </body>
</html>